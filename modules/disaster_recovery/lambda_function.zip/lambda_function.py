import boto3
import datetime

def lambda_handler(event, context):
    current_time = datetime.datetime.now().isoformat()
    print(f"[INFO] Executando verificação de DR às {current_time}")
    return {
        'statusCode': 200,
        'body': f'Disaster Recovery executado com sucesso em {current_time}'
    }
